#!/bin/sh
set -eu
printf '%s\n' '{"p_blue_win": 0, "p_blue_ahead_15": 1}' > /app/prediction.json
